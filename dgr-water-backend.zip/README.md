# DGR Water Backend

This is the Node.js backend for the DGR Water Supply System.

## Run locally
```
npm install
npm start
```

## Deploy on Render
- Create new Web Service
- Select this repo
- Build command: npm install
- Start command: npm start
